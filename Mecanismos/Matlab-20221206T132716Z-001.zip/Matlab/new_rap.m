%F=[f1;f2];             vetor de v�nculos
%S=[teta2;teta3];       vetor das vari�veis secund�rias
%J=jacobian(F,S);       matriz jacobiana
%P_fun                  fun��o P(t) da variavel primaria

function [P, S] = new_rap(F,J,S,S_0,P,P_fun,N,eps1,eps2,dt,t_i,t_f)
t=[t_i:dt:t_f].';     % tempo de simula��o
S_r= ones(1, (t_f-t_i)/dt+1);
for j=1:length(t)
    str=['Itera��o ',num2str(j),' de ',num2str(length(t))]; disp(str);
    P_fun=P_fun
    S=S
    P=P
    %P=P_fun(j)
    P=double(subs(P_fun(j)))
    %P=double(P_fun(j));
        for i=1:N
            S_1=(S_0-subs(J)\subs(F))
            S_1=double(S_1)
                if norm(S_1-S_0)<=eps2         % toler�ncia em dx
%                     fprintf('Atingiu a toler�ncia de erro em dx com %0.0f itera��es.\n', i)
                        break
                elseif norm(eval(F))<=eps1   % toler�ncia em dy             
%                     fprintf('Atingiu a toler�ncia de erro em dy com %0.0f itera��es.\n', i)
                        break                    
                end
            S_0=S_1;
        end
S_r(j)=S_1;
clc;
end
end
