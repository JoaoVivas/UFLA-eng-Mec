%% PROGRAMA MATLAB PARA RESOLU��O DE SISTEMA DE EQUA��ES N�O-LINEARES POR NEWTON-RAPHSON
% Vers�o: MATLAB R2016a
% Autor: Prof. Dr. Henrique Leandro Silveira (Engenharia Mec�nica/UFLA)
% Data: 01/06/2017
% Revis�o 1: 

clear all; clc; close all;
% Declara��o das vari�veis simb�licas
syms L1 L2 L3 L4 yd  % par�metros
syms teta1 P        % vari�veis prim�rias
syms teta2 teta3 t   % vari�veis secund�rias

% Equa��es de loop (restri��es geom�tricas)
P=sym([teta1]);
S=sym([teta2;teta3]);
f1=L1*cos(P)+L2*cos(S(1))-L3*cos(S(2))-L4
f2=L1*sin(P)+L2*sin(S(1))-L3*sin(S(2))-yd

F=[f1;f2];           % vetor de v�nculos
     % vetor das vari�veis secund�rias
J=jacobian(F,S);     % matriz jacobiana

% Dados num�ricos
L1=0.5;              % comprimento da barra 1 [m]
L2=0.9;              % comprimento da barra 2 [m]
L3=0.7;              % comprimento da barra 3 [m]
L4=1.0;              % comprimento da barra 4 [m]
yd=0*0.1;              % dist�ncia vertical entre os mancais A e C [m]

F=subs(F)
J=subs(J)

teta10=60*pi/180;    % posi��o angular da barra 1 [rad]
dteta10=120*pi/30;   % velocidade angular da barra 1 [rad/s]
d2teta1=0;           % acelera��o angular da barra 1 [rad/s�]

teta2=10*pi/180;     % estimativa inicial da posi��o angular da barra 2 [rad]
teta3=45*pi/180;     % estimativa inicial da posi��o angular da barra 3 [rad]

eps1=10^-4;          % toler�ncia de erro para as ordenadas (dy=y2-y1)
eps2=10^-4;          % toler�ncia de erro para as abscissas (dx=x2-x1)
N=20;                % n�mero m�ximo de itera��es 
S_0=double(subs(S))          % avalia��o num�rica do vetor de vari�veis secund�rias

% Par�metros de simula��o
dt=0.01;             % incremento de integra��o
tmax=2;              % tempo m�ximo de simula��o
%t=[0:dt:tmax].';     % tempo de simula��o
% Solu��o num�rica das equa��es n�o-lineares pelo m�todo de Newton-Raphson
teta1=(subs(teta10+dteta10*t+1/2*d2teta1*t.^2))

[P, S] = new_rap(F,J,S,S_0,P,P_fun,N,eps1,eps2,dt,0,tmax);

% if i>=N
%     fprintf('N�o atingiu a toler�ncia de erro com o n�mero de itera��es.')
% end

ms;
my;

% Resultados num�ricos
teta1=P;
teta2=S(1);
teta3=S(2);

Xa=L1*cos(teta1);
Ya=L1*sin(teta1);
Xb=Xa+L2*cos(teta2);
Yb=Ya+L2*sin(teta2);
Xc=L4*ones(length(t),1);
Yc=yd*ones(length(t),1);

% Gr�ficos de resposta
figure('color','w');
plot(t,teta1*180/pi,t,teta2*180/pi,t,teta3*180/pi)
legend('teta1','teta2','teta3')
title('Trajet�ria do mecanismo');
xlabel('t (s)')
ylabel('\theta (graus)')

% Anima��o gr�fica
figure('color','w');
for i=1:1:length(t)
clf

line([0,Xa(i)],[0,Ya(i)],'LineWidth',5,'Color',[0.5 0.5 0]);
line([Xa(i),Xb(i)],[Ya(i),Yb(i)],'LineWidth',5,'Color',[1 0 0]);
line([Xc(i),Xb(i)],[Yc(i),Yb(i)],'LineWidth',5,'Color',[0 0 1]);

axis equal; grid on; hold on; 
axis([-1.1*abs(max(Xa)) 1.1*abs(max(Xb)) -1.1*abs(max(Ya)) 1.1*abs(max(Yb))]);
title('Trajet�ria das barras');
xlabel('X (m)')
ylabel('Y (m)')

text(0,0,'  O','FontSize',10);
text(Xa(i),Ya(i),'  A','FontSize',10);
text(Xb(i),Yb(i),'  B','FontSize',10);
text(Xc(i),Yc(i),'  C','FontSize',10);

text(1.08*abs(max(Xb)),0,['t=',num2str(t(i)),'/',num2str(t(end)),'s'],'FontSize',10);

pause(0.01)
end

%% FIM DO PROGRAMA