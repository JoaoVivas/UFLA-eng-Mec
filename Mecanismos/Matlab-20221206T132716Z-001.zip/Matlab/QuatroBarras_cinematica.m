%% PROGRAMA MATLAB PARA MODELAGEM CINEM�TICA DO MECANISMO DE QUATRO BARRAS
% Resolu��o utilizando o programa "fulldiff.m", que realiza a derivada com rela��o ao tempo das vari�veis indicadas.
% Este programa acessa o M-File "fulldiff.m", que dever� estar na pasta raiz do MATLAB.
% Vers�o: MATLAB R2016a
% Autor: Prof. Dr. Henrique Leandro Silveira (Engenharia Mec�nica/UFLA)
% Data: 18/12/2011
% Revis�o 3: 28/10/2017

clear all; close all; clc;
% PARTE I - CINEM�TICA
% Declara��o das vari�veis simb�licas
syms teta1 dteta1 d2teta1 teta2 dteta2 d2teta2 teta3 dteta3 d2teta3  % variam no tempo

% Declara��o dos par�metros do sistema mec�nico
syms L1 L2 L3 L4 L5 d R yc  % n�o variam no tempo

% Defini��o das matrizes de transforma��o de coordenadas
T_teta1=[cos(teta1) -sin(teta1) 0; sin(teta1) cos(teta1) 0; 0 0 1]         % relaciona a base 1 solid�ria � barra OA com a base inercial
T_teta2=[cos(teta2) sin(teta2) 0; -sin(teta2) cos(teta2) 0; 0 0 1]         % relaciona a base 2 solid�ria � barra AB com a base inercial
T_teta3=[cos(teta3) sin(teta3) 0; -sin(teta3) cos(teta3) 0; 0 0 1]         % relaciona a base 3 solid�ria � barra CB com a base inercial

% Representa��o dos vetores posi��o
r_b1_oa=[0;L1;0]                     % comprimento da barra OA (manivela)
r_i_oa=T_teta1.'*r_b1_oa
T_teta1.'
r_b1_of=[-R;d;0]                     % comprimento da barra OF 
r_i_of=T_teta1.'*r_b1_of

r_b2_ab=[L2;0;0]                     % comprimento da barra AB (acoplador)
r_i_ab=T_teta2.'*r_b2_ab

r_b3_cb=[L3;-L4;0]                     % comprimento da barra CB (seguidor)
r_i_cb=T_teta3.'*r_b3_cb

r_b3_ce=[L3;-L5;0]                     % comprimento da barra CE (ponto de interesse)
r_i_ce=T_teta3.'*r_b3_ce

r_i_oc=[0;yc;0]                      % dist�ncia entre os mancais O e C

% Representa��o dos vetores velocidade angular absoluta
w_b1_1=[0;0;fulldiff(teta1,{teta1,teta2,teta3})]
w_b2_2=[0;0;fulldiff(teta2,{teta1,teta2,teta3})]
w_b3_3=[0;0;fulldiff(teta3,{teta1,teta2,teta3})]

% Representa��o dos vetores acelera��o angular absoluta
dw_b1_1=fulldiff(w_b1_1,{teta1,teta2,teta3})
dw_b2_2=fulldiff(w_b2_2,{teta1,teta2,teta3})
dw_b3_3=fulldiff(w_b3_3,{teta1,teta2,teta3})

% Determina��o dos vetores de velocidade linear absoluta
v_b1_o=sym([0;0;0])

v_b1_a=v_b1_o+cross(w_b1_1,r_b1_oa)
v_i_a=T_teta1.'*v_b1_a                           % vetor velocidade linear absoluta do ponto A

v_b2_a=T_teta2*v_i_a
v_b2_b=v_b2_a+cross(w_b2_2,r_b2_ab)              % vetor velocidade linear absoluta do ponto B
v_i_b=T_teta2.'*v_b2_b

v_b3_c=sym([0;0;0])

% Determina��o dos vetores acelera��o linear absoluta
a_b1_o=sym([0;0;0])

a_b1_a=a_b1_o+cross(dw_b1_1,r_b1_oa)+cross(w_b1_1,cross(w_b1_1,r_b1_oa))
a_i_a=T_teta1.'*a_b1_a                           % vetor acelera��o linear absoluta do ponto A

a_b2_a=T_teta2*a_i_a

a_b2_b=a_b2_a+cross(dw_b2_2,r_b2_ab)+cross(w_b2_2,cross(w_b2_2,r_b2_ab))
a_i_b=T_teta2.'*a_b2_b                           % vetor acelera��o linear absoluta do ponto B

a_b3_c=sym([0;0;0])

% Restri��es geom�tricas do mecanismo
eq1=r_i_oa+r_i_ab-r_i_oc-r_i_cb            % equa��o de restri��o geom�trica (equa��o de v�nculo para as posi��es angulares)
eq2=fulldiff(eq1,{teta1,teta2,teta3})      % equa��o de v�nculo para as velocidades angulares
eq3=fulldiff(eq2,{teta1,teta2,teta3})      % equa��o de v�nculo para as acelera��es angulares

f=eq1(1:2)                                 % vetor de v�nculos

q=[teta1]                                  % vetor de vari�veis prim�rias
S=[teta2;teta3]                            % vetor de vari�veis secund�rias
J=jacobian(f,S)                            % matriz jacobiana

% An�lise de velocidade
B=-jacobian(f,q)                           % matriz das velocidades prim�rias
K=simplify(J\B)                            % matriz de coeficientes de velocidade
dq=fulldiff(q,{teta1})                     % vetor de velocidades prim�rias
dS=K*dq                                    % vetor de velocidades secund�rias

% An�lise de acelera��o
d2q=fulldiff(q,{teta1},2)                  % vetor de acelera��es prim�rias
L_1=diff(K,teta1)+diff(K,teta2)*K(1,1)+diff(K,teta3)*K(2,1) % matriz da derivada dos coeficientes de velocidade
d2S=K*d2q+(dq(1)*L_1)*dq                   % vetor de acelera��es secund�rias

% dJ=fulldiff(J,{teta1,teta2,teta3}) 
% dB=fulldiff(B,{teta1,teta2,teta3})
% eq4=J*[d2teta2;d2teta3]-B*d2q-(dB-dJ*K)*dq
% eq4a=J*[d2teta2;d2teta3]-B*d2q-dB*dq+dJ*[dteta2;dteta3]
% check3a=simplify(subs(eq4a-eq3(1:2)))
% L_1=J\(diff(B,teta1)-diff(J,teta1)*K)

%% Resolu��o do sistema de equa��es para as vari�veis desconhecidas
% Resolu��o do sistema de equa��es das restri��es geom�tricas
A0=solve(eq3(1),eq3(2),d2teta2,d2teta3)
A1=solve(eq2(1),eq2(2),dteta2,dteta3)

% Armazenamento das vari�veis
dteta2=simplify(subs(A1.dteta2))
dteta3=simplify(subs(A1.dteta3))
d2teta2=simplify(subs(A0.d2teta2))
d2teta3=simplify(subs(A0.d2teta3))

check1=simplify(dS(1)-dteta2)
check2=simplify(dS(2)-dteta3)
check3=simplify(d2S(1)-d2teta2)
check4=simplify(d2S(2)-d2teta3)
% check3=simplify(subs(eq4-eq3(1:2)))

%% FIM DO PROGRAMA