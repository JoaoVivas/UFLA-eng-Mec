function F = func_fsolve(S)

global L1 L2 L3 L4 teta1 yd

teta2=S(1);
teta3=S(2);

F=[L1*cos(teta1)+L2*cos(teta2)-L3*cos(teta3)-L4;
   L1*sin(teta1)+L2*sin(teta2)-L3*sin(teta3)-yd];