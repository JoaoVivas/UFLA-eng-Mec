%% PROGRAMA MATLAB PARA RESOLU��O NUM�RICA DE SISTEMA DE EQUA��ES N�O-LINEARES DO MECANISMO DE QUATRO BARRAS
% Vers�o: MATLAB R2016a
% Autor: Prof. Dr. Henrique Leandro Silveira (Engenharia Mec�nica/UFLA)
% Data: 17/10/2017
% Revis�o 1: 

clear all; clc; close all;
%% Dados de entrada 
global L1 L2 L3 L4 teta1 yd

L1=0.50;
L2=0.90;
L3=0.70;
L4=1.00;
yd=0.10;

% Par�metros de simula��o
dt=0.01;             % incremento de integra��o
tmax=2;              % tempo m�ximo de simula��o
t=[0:dt:tmax].';     % tempo de simula��o

teta10=60*pi/180;    % posi��o angular da barra 1 [rad]
dteta10=120*pi/30;   % velocidade angular da barra 1 [rad/s]
d2teta1=0;           % acelera��o angular da barra 1 [rad/s�]

Teta1=teta10+dteta10*t+1/2*d2teta1*t.^2;

S0=[deg2rad(10); deg2rad(45)];  % estimativa inicial [teta2; teta3]

options0=optimoptions('fsolve','Display','iter','MaxIter',20,'MaxFunEvals',3000,'TolFun',1e-10,'TolX',1e-10);

for j=1:length(t)
    str=['Itera��o ',num2str(j),' de ',num2str(length(t))]; disp(str);
    teta1=Teta1(j);
        S=fsolve(@func_fsolve,S0,options0);
            teta2(j,1)=S(1);
            teta3(j,1)=S(2);
            S0=[teta2(j); teta3(j)];
%             pause
clc;
end
%% Resultados num�ricos
teta1=Teta1;

Xa=L1*cos(teta1);
Ya=L1*sin(teta1);
Xb=Xa+L2*cos(teta2);
Yb=Ya+L2*sin(teta2);
Xc=L4*ones(length(t),1);
Yc=yd*ones(length(t),1);

%% Gr�ficos de resposta
figure('color','w');
plot(t,teta1*180/pi,t,teta2*180/pi,t,teta3*180/pi)
legend('teta1','teta2','teta3')
title('Trajet�ria das barras');
xlabel('t (s)')
ylabel('\theta (graus)')

%% Anima��o gr�fica
figure('color','w');
for i=1:1:length(t)
clf

line([0,Xa(i)],[0,Ya(i)],'LineWidth',5,'Color',[0.5 0.5 0]);
line([Xa(i),Xb(i)],[Ya(i),Yb(i)],'LineWidth',5,'Color',[1 0 0]);
line([Xc(i),Xb(i)],[Yc(i),Yb(i)],'LineWidth',5,'Color',[0 0 1]);

axis equal; grid on; hold on; 
axis([-1.1*abs(max(Xa)) 1.1*abs(max(Xb)) -1.1*abs(max(Ya)) 1.1*abs(max(Yb))]);
title('Trajet�ria do mecanismo');
xlabel('X (m)')
ylabel('Y (m)')

text(0,0,'  O','FontSize',10);
text(Xa(i),Ya(i),'  A','FontSize',10);
text(Xb(i),Yb(i),'  B','FontSize',10);
text(Xc(i),Yc(i),'  C','FontSize',10);

text(1.08*abs(max(Xb)),0,['t=',num2str(t(i)),'/',num2str(t(end)),'s'],'FontSize',10);

pause(0.01)
end

%% FIM DO PROGRAMA