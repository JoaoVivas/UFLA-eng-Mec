%% PROGRAMA MATLAB PARA MODELAGEM CINEM�TICA DO MECANISMO DA ATIVIDADE 1
% Resolu��o utilizando o programa "fulldiff.m", que realiza a derivada com rela��o ao tempo das vari�veis indicadas.
% Este programa acessa o M-File "fulldiff.m", que dever� estar na pasta raiz do MATLAB.
% Vers�o: MATLAB R2016a
% Autor: Joao Vivas Cisalpino 201610824
% Baseado no programa do Prof. Dr. Henrique Leandro Silveira (Engenharia Mec�nica/UFLA)
% Data de entrega: 31/01/2022

clear all; close all; clc;
% PARTE I - CINEM�TICA
% Declara��o das vari�veis simb�licas
syms teta dteta d2teta alpha dalpha d2alpha ss1 dss1 d2ss1 ss2 dss2 d2ss2 ss3 dss3 d2ss2 % variam no tempo

% Declara��o dos par�metros do sistema mec�nico
syms L1 L2 % n�o variam no tempo
syms t
% Defini��o das matrizes de transforma��o de coordenadas
T_teta=[cos(teta) -sin(teta) 0; sin(teta) cos(teta) 0; 0 0 1]
T_alpha=[cos(alpha) sin(alpha) 0; -sin(alpha) cos(alpha) 0; 0 0 1] 
% Representa��o dos vetores posi��o

r_i_oc=[ss1;0;0]           

r_b1_ob=[0;ss2;0]                    
r_i_ob=T_teta.'*r_b1_ob

r_b1_oa=[ss3;0;0]                    
r_i_oa=T_teta.'*r_b1_oa

r_b2_ba=[L1;0;0]                    
r_i_ba=T_alpha.'*r_b2_ba

r_b2_ac=[L2;0;0]
r_i_ac=T_alpha.'*r_b2_ac

% Restri��es geom�tricas do mecanismo
eq1=r_i_ob+r_i_ba-r_i_oa
eq2=r_i_oc-r_i_ob-r_i_ba-r_i_ac

%
f=[eq1(1);eq1(2);eq2(1);eq2(2)]            % vetor de v�nculos

q=[teta]                                  % vetor de vari�veis prim�rias
S=[alpha;ss1;ss2;ss3]                            % vetor de vari�veis secund�rias
J=jacobian(f,S)                            % matriz jacobiana

% Dados num�ricos

L1=0.38;
L2=0.75;

alpha = 0.1745
ss1 = 0.75
ss2 = 0.2
ss3 = 0.18

eps1=10^-4;          % toler�ncia de erro para as ordenadas (dy=y2-y1)
eps2=10^-4;          % toler�ncia de erro para as abscissas (dx=x2-x1)
N=20;                % n�mero m�ximo de itera��es 
S0=eval(S);          % avalia��o num�rica do vetor de vari�veis secund�rias

% Solu��o num�rica das equa��es n�o-lineares pelo m�todo de Newton-Raphson

%Teta1=exp(-zeta*omegan*t)*(A_1*cos(omegad*t)+A_2*sin(omegad*t))+ deg2rad(delang);
Teta=0.5+t*pi;

% Par�metros de simula��o
t_i=0;               % Tempo inicial
t_f=2;               % Tempo final
dt=0.01;             % incremento de integra��o
t=[t_i:dt:t_f].';     % tempo de simula��o

Teta=eval(Teta);

for j=1:length(t)
    str=['Itera��o ',num2str(j),' de ',num2str(length(t))]; disp(str);
    teta=Teta(j);
        for i=1:N
            S1=S0-eval(J)\eval(f);
            alpha=S1(1);
            ss1=S1(2);
            ss2=S1(3);
            ss3=S1(4);
                if norm(S1-S0)<=eps2         % toler�ncia em dx
%                     fprintf('Atingiu a toler�ncia de erro em dx com %0.0f itera��es.\n', i)
                        break
                elseif norm(eval(f))<=eps1   % toler�ncia em dy             
%                     fprintf('Atingiu a toler�ncia de erro em dy com %0.0f itera��es.\n', i)
                        break                    
                end
            S0=S1;
        end
Alpha(j,1)=alpha;
Ss1(j,1)=ss1;
Ss2(j,1)=ss2;
Ss3(j,1)=ss3;
clc;
end

% Resultados num�ricos
teta=Teta;
alpha=Alpha;
ss1=Ss1;
ss2=Ss2;
ss3=Ss3;

Xa=eval(r_i_oa(1));
Ya=eval(r_i_oa(2));
Xb=eval(r_i_ob(1));
Yb=eval(r_i_ob(2));
Xc=eval(r_i_oc(1));
Yc=eval(r_i_oc(2));

% Anima��o gr�fica
figure('color','w');
for i=1:1:length(t)
clf

line([0,Xa(i)],[0,Ya(i)],'LineWidth',5,'Color',[1 0 0]);
line([0,Xb(i)],[0,Yb(i)],'LineWidth',5,'Color',[0 1 0]);
line([Xa(i),Xb(i)],[Ya(i),Yb(i)],'LineWidth',5,'Color',[0 0 1]);
line([Xb(i),Xc(i)],[Yb(i),0],'LineWidth',5,'Color',[1 1 0]);

axis equal; grid on; hold on; 
axis([1.1*(min([min(Xa),min(Xb),min(Xc)])) 1.1*(max([max(Xa),max(Xb),max(Xc)])) 1.1*(min([min(Ya),min(Yb),0])) 1.1*(max([max(Ya),max(Yb),0]))]);
title('Trajet�ria das barras');
xlabel('X (m)')
ylabel('Y (m)')

text(0,0,'  O','FontSize',10);
text(Xa(i),Ya(i),'  A','FontSize',10);
text(Xb(i),Yb(i),'  B','FontSize',10);
text(Xc(i),0,'  C','FontSize',10);

drawnow
end

%% FIM DO PROGRAMA