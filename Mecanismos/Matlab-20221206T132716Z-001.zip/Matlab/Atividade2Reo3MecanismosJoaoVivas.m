%% PROGRAMA MATLAB PARA MODELAGEM CINEM�TICA DO MECANISMO DA ATIVIDADE 1
% Resolu��o utilizando o programa "fulldiff.m", que realiza a derivada com rela��o ao tempo das vari�veis indicadas.
% Este programa acessa o M-File "fulldiff.m", que dever� estar na pasta raiz do MATLAB.
% Vers�o: MATLAB R2016a
% Autor: Joao Vivas Cisalpino 201610824
% Baseado no programa do Prof. Dr. Henrique Leandro Silveira (Engenharia Mec�nica/UFLA)
% Data de entrega: 31/01/2022

clear all; close all; clc;
% PARTE I - CINEM�TICA
% Declara��o das vari�veis simb�licas
syms teta1 dteta1 d2teta1 teta2 dteta2 d2teta2 teta3 dteta3 d2teta3 teta4 dteta4 d2teta4 teta5 dteta5 d2teta5 teta6 dteta6 d2teta6 teta7 dteta7 d2teta7 teta8 dteta8 d2teta8 teta9 dteta9 d2teta9 teta10 dteta10 d2teta10 teta11 dteta11 d2teta11 % variam no tempo

% Declara��o dos par�metros do sistema mec�nico
syms L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 xc yc  % n�o variam no tempo
syms t
% Defini��o das matrizes de transforma��o de coordenadas
T_teta1=[cos(teta1) -sin(teta1) 0; sin(teta1) cos(teta1) 0; 0 0 1]
T_teta3=[cos(teta3) -sin(teta3) 0; sin(teta3) cos(teta3) 0; 0 0 1] 
T_teta4=[cos(teta4) -sin(teta4) 0; sin(teta4) cos(teta4) 0; 0 0 1] 
T_teta6=[cos(teta6) -sin(teta6) 0; sin(teta6) cos(teta6) 0; 0 0 1] 
T_teta7=[cos(teta7) -sin(teta7) 0; sin(teta7) cos(teta7) 0; 0 0 1] 
T_teta10=[cos(teta10) -sin(teta10) 0; sin(teta10) cos(teta10) 0; 0 0 1] 

T_teta2=[cos(teta2) sin(teta2) 0; -sin(teta2) cos(teta2) 0; 0 0 1]         % relaciona a base 2 solid�ria � barra AB com a base inercial
T_teta5=[cos(teta5) sin(teta5) 0; -sin(teta5) cos(teta5) 0; 0 0 1]         % relaciona a base 2 solid�ria � barra AB com a base inercial
T_teta8=[cos(teta8) sin(teta8) 0; -sin(teta8) cos(teta8) 0; 0 0 1]         % relaciona a base 2 solid�ria � barra AB com a base inercial
T_teta9=[cos(teta9) sin(teta9) 0; -sin(teta9) cos(teta9) 0; 0 0 1]         % relaciona a base 2 solid�ria � barra AB com a base inercial
T_teta11=[cos(teta11) sin(teta11) 0; -sin(teta11) cos(teta11) 0; 0 0 1]         % relaciona a base 3 solid�ria � barra CB com a base inercial

% Representa��o dos vetores posi��o

r_i_oc=[xc;yc;0]           

r_b1_oa=[L1;0;0]                    
r_i_oa=T_teta1.'*r_b1_oa

r_b2_ab=[0;L2;0]                    
r_i_ab=T_teta2.'*r_b2_ab

r_b3_ad=[L4;0;0]
r_i_ad=T_teta3.'*r_b3_ad

r_b11_bc=[0;-L3;0]                   
r_i_bc=T_teta11.'*r_b11_bc

r_b4_bg=[L5;0;0]                   
r_i_bg=T_teta4.'*r_b4_bg 

r_b5_cg=[L6;0;0]                   
r_i_cg=T_teta5.'*r_b5_cg   

r_b6_cd=[L7;0;0]                   
r_i_cd=T_teta6.'*r_b6_cd   

r_b7_gf=[L8;0;0]                   
r_i_gf=T_teta7.'*r_b7_gf   

r_b8_fd=[-L9;0;0]                   
r_i_fd=T_teta8.'*r_b8_fd   

r_b9_de=[0;-L10;0]                   
r_i_de=T_teta9.'*r_b9_de   

r_b10_fe=[0;-L11;0]                   
r_i_fe=T_teta10.'*r_b10_fe    

r_i_oe=r_i_oa+r_i_ad+r_i_de

% Restri��es geom�tricas do mecanismo
eq1=r_i_oa+r_i_ab-r_i_oc+r_i_bc     % equa��o de restri��o geom�trica (equa��o de v�nculo para as posi��es angulares)
eq2=r_i_oa+r_i_ad-r_i_oc-r_i_cd
eq3=r_i_bc+r_i_cg-r_i_bg
eq4=r_i_cg+r_i_gf-r_i_cd+r_i_fd
eq5=r_i_fe-r_i_fd-r_i_de
%
F=[eq1(1);eq1(2);eq2(1);eq2(2);eq3(1);eq3(2);eq4(1);eq4(2);eq5(1);eq5(2)]                                 % vetor de v�nculos

q=[teta1]                                  % vetor de vari�veis prim�rias
S=[teta2;teta3;teta4;teta5;teta6;teta7;teta8;teta9;teta10;teta11]                            % vetor de vari�veis secund�rias
J=jacobian(F,S)                            % matriz jacobiana


% Dados num�ricos

L1=0.046;
L2=0.152;
L3=0.126;
L4=0.188;
L5=0.170;
L6=0.122;
L7=0.120;
L8=0.120;
L9=0.112;
L10=0.149;
L11=0.200;
xc=0.116;
yc=-0.024;

%L1=0.5;              % comprimento da barra 1 [m]
%L2=0.9;              % comprimento da barra 2 [m]
%L3=0.7;              % comprimento da barra 3 [m]
%L4=1.0;              % comprimento da barra 4 [m]
%yd=0*0.1;              % dist�ncia vertical entre os mancais A e C [m]

teta2=pi/6;     
teta3=pi/4;
teta4=pi/5;
teta5=pi/16;
teta6=pi/2;
teta7=pi/4;
teta8=pi/16;
teta9=pi/8;
teta10=pi/9;
teta11=0;

eps1=10^-4;          % toler�ncia de erro para as ordenadas (dy=y2-y1)
eps2=10^-4;          % toler�ncia de erro para as abscissas (dx=x2-x1)
N=50;                % n�mero m�ximo de itera��es 
S0=eval(S);          % avalia��o num�rica do vetor de vari�veis secund�rias

% Solu��o num�rica das equa��es n�o-lineares pelo m�todo de Newton-Raphson

%Teta1=exp(-zeta*omegan*t)*(A_1*cos(omegad*t)+A_2*sin(omegad*t))+ deg2rad(delang);
Teta1=2*pi*(t);

% Par�metros de simula��o
t_i=0;               % Tempo inicial
t_f=2;               % Tempo final
dt=0.01;             % incremento de integra��o
t=[t_i:dt:t_f].';     % tempo de simula��o

Teta1=eval(Teta1);

for j=1:length(t)
    str=['Itera��o ',num2str(j),' de ',num2str(length(t))]; disp(str);
    teta1=Teta1(j);
        for i=1:N
            S1=S0-eval(J)\eval(F);
            teta2=S1(1);
            teta3=S1(2);
            teta4=S1(3);
            teta5=S1(4);
            teta6=S1(5);
            teta7=S1(6);
            teta8=S1(7);
            teta9=S1(8);
            teta10=S1(9);
            teta11=S1(10);
                if norm(S1-S0)<=eps2         % toler�ncia em dx
%                     fprintf('Atingiu a toler�ncia de erro em dx com %0.0f itera��es.\n', i)
                        break
                elseif norm(eval(F))<=eps1   % toler�ncia em dy             
%                     fprintf('Atingiu a toler�ncia de erro em dy com %0.0f itera��es.\n', i)
                        break                    
                end
            S0=S1;
        end
Teta2(j,1)=teta2;
Teta3(j,1)=teta3;
Teta4(j,1)=teta4;
Teta5(j,1)=teta5;
Teta6(j,1)=teta6;
Teta7(j,1)=teta7;
Teta8(j,1)=teta8;
Teta9(j,1)=teta9;
Teta10(j,1)=teta10;
Teta11(j,1)=teta11;
clc;
end

% Resultados num�ricos
teta1=Teta1;
teta2=Teta2;
teta3=Teta3;
teta4=Teta4;
teta5=Teta5;
teta6=Teta6;
teta7=Teta7;
teta8=Teta8;
teta9=Teta9;
teta10=Teta10;
teta11=Teta11;

Xa=eval(r_i_oa(1));
Ya=eval(r_i_oa(2));
Xb=Xa+eval(r_i_ab(1));
Yb=Ya+eval(r_i_ab(2));
Xc=xc*ones(length(t),1);
Yc=yc*ones(length(t),1);
Xd=Xc+eval(r_i_cd(1));
Yd=Yc+eval(r_i_cd(2));
Xe=Xd+eval(r_i_de(1));
Ye=Yd+eval(r_i_de(2));
Xg=Xb+eval(r_i_bg(1));
Yg=Yb+eval(r_i_bg(2));
Xf=Xg+eval(r_i_gf(1));
Yf=Yg+eval(r_i_gf(2));

% Gr�ficos de resposta
figure('color','w');
plot(t,teta1*180/pi,t,teta2*180/pi,t,teta3*180/pi)
legend('teta1','teta2','teta3')
title('Trajet�ria do mecanismo');
xlabel('t (s)')
ylabel('\theta (graus)')

% Anima��o gr�fica
figure('color','w');
h1 = animatedline('Color', 'red');
for i=1:1:length(t)
clf

line([0,Xa(i)],[0,Ya(i)],'LineWidth',5,'Color',[0.5 0.5 0]);
line([Xa(i),Xb(i)],[Ya(i),Yb(i)],'LineWidth',5,'Color',[1 0 0]);
line([Xa(i),Xd(i)],[Ya(i),Yd(i)],'LineWidth',5,'Color',[1 0 0]);
line([Xc(i),Xb(i)],[Yc(i),Yb(i)],'LineWidth',5,'Color',[1 0 0]);
line([Xc(i),Xd(i)],[Yc(i),Yd(i)],'LineWidth',5,'Color',[0 0 1]);
line([Xc(i),Xg(i)],[Yc(i),Yg(i)],'LineWidth',5,'Color',[0 0 1]);
line([Xb(i),Xg(i)],[Yb(i),Yg(i)],'LineWidth',5,'Color',[0 0 1]);
line([Xd(i),Xe(i)],[Yd(i),Ye(i)],'LineWidth',5,'Color',[0 0 1]);
line([Xd(i),Xf(i)],[Yd(i),Yf(i)],'LineWidth',5,'Color',[0 0 1]);
line([Xg(i),Xf(i)],[Yg(i),Yf(i)],'LineWidth',5,'Color',[0.5 0.5 0]);
line([Xf(i),Xe(i)],[Yf(i),Ye(i)],'LineWidth',5,'Color',[0.5 0.5 0]);

axis equal; grid on; hold on; 
axis([1.1*(min([min(Xa),min(Xb),min(Xc),min(Xd),min(Xe),min(Xf),min(Xg)])) 1.1*(max([max(Xa),max(Xb),max(Xc),max(Xd),max(Xe),max(Xf),max(Xg)])) 1.1*(min([min(Ya),min(Yb),min(Yc),min(Yd),min(Ye),min(Yf),min(Yg)])) 1.1*(max([max(Ya),max(Yb),max(Yc),max(Yd),max(Ye),max(Yf),max(Yg)]))]);
title('Trajet�ria das barras');
xlabel('X (m)')
ylabel('Y (m)')

text(0,0,'  O','FontSize',10);
text(Xa(i),Ya(i),'  A','FontSize',10);
text(Xb(i),Yb(i),'  B','FontSize',10);
text(Xc(i),Yc(i),'  C','FontSize',10);
text(Xd(i),Yd(i),'  D','FontSize',10);
text(Xg(i),Yg(i),'  G','FontSize',10);
text(Xf(i),Yf(i),'  F','FontSize',10);
text(Xe(i),Ye(i),'  E','FontSize',10);
addpoints(h1,Xe(i),Ye(i));
drawnow
text(1.08*abs(max(Xb)),0,['t=',num2str(t(i)),'/',num2str(t(end)),'s'],'FontSize',10);
end

%% FIM DO PROGRAMA